/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletCorrobora extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection db = DriverManager.getConnection("jdbc:mysql://localhost:3306/usuarios","root", "");
            Statement s = db.createStatement();
            String sid=request.getParameter("id");
               String dato=request.getParameter("dato");
                String dato2=request.getParameter("dato2");
            String sql = "select * from reto where id = "+sid+";";
            ResultSet users = s.executeQuery(sql);
          
             ServletEjercicio usuario=null;
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Informacion Registro</title>");      
                                                out.println("<link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3\" crossorigin=\"anonymous\">");

            out.println("</head>");
            out.println("<body>");
            out.println("<table class='table'>");
            out.println("<tr>");
            out.println("<td>ID</td>");
            out.println("<td>PuntoA</td>");
            out.println("<td>PuntoB</td>");
            out.println("<td>PuntoC</td>");
            out.println("<td>PuntoD</td>");
            out.println("</tr>");
            while(users.next()){
                usuario = new ServletEjercicio();
                usuario.setId(users.getInt("id"));
                usuario.setPuntoA(users.getString("puntoA"));
                usuario.setPuntoB(users.getString("puntoB"));
        
                out.println("<tr>");
                out.println("<td>"+usuario.getId()+"</td>");
                out.println("<td>"+usuario.getPuntoA()+"</td>");
                out.println("<td>"+usuario.getPuntoB()+"</td>");   
  
                out.println("</tr>");
            }
            out.println("</table><br><br>");
            double a=Integer.parseInt(usuario.getPuntoA());
             double b=Integer.parseInt(usuario.getPuntoB());
         
            if(a==Integer.parseInt(dato) && b==Integer.parseInt(dato2)){
                         out.println("<a href=\"ServletPrincipal\" class='btn btn-success'>Muy bien voler al CRUD</a>");  
            }else{
                        out.println("<a href=\"ServletPrincipal\" class='btn btn-danger'>Error voler al CRUD</a>"); 
            }
        
            out.println("</body>");
            out.println("</html>");
        }catch(Exception ex){
            
        }
    }
}


