package paquete;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServleteTrabajo extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        try{
         
            String sid=request.getParameter("id");
          
            
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Informacion Registro</title>");     
                        out.println("<link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3\" crossorigin=\"anonymous\">");

            out.println("</head>");
            out.println("<body>");
                        out.println("<h1 class='p-3 mb-2 bg-danger text-white'>Elija su actividad</h1><br />");

            out.println("	<script type=\"text/javascript\">\n" +
"		function verificar(){\n" +
"			if (document.getElementById('1').checked) {\n" +
"				window.location.href = \"servletRealiza?id="+sid+"\";\n" +
"			}\n" +
"				if (document.getElementById('2').checked) {\n" +
"				window.location.href = \"ServletRealiza2?id="+sid+"\";\n" +
"			}\n" +
"		}\n" +
"	</script>\n" +
"	<form class='form-group'>\n" +
"<label><input type=\"checkbox\" id=\"1\" class=\"form-check-input\">Calcular punto medio</label><br>\n" +
"<input type=\"button\" value=\"Iniciar\" onclick=\"verificar()\" class=\"btn btn-primary\" >\n" +
"</form>");
            out.println("<a href=\"ServletPrincipal\" class='btn btn-info'>Volver al CRUD</a>");
            out.println("</body>");
            out.println("</html>");
        }catch(Exception ex){
            
        }
    }
}