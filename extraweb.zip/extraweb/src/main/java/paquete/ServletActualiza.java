/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ServletActualiza extends HttpServlet 
{
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        HttpSession sesion=request.getSession();
    String puntoA = request.getParameter("puntoA");
    String puntoB = request.getParameter("puntoB");

    String sid=(String)sesion.getAttribute("id");
    int id=Integer.parseInt(sid);
    String sql="UPDATE reto SET puntoA='"+puntoA+"',puntoB='"+puntoB+"' WHERE id="+id+";";
            response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Editar usuario</title>");     
                        out.println("<link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3\" crossorigin=\"anonymous\">");

            out.println("</head>");
            out.println("<body>");
    try
    {
    Class.forName("com.mysql.jdbc.Driver");
    Connection db = DriverManager.getConnection("jdbc:mysql://localhost:3306/usuarios","root", "");
    Statement s = db.createStatement();        
    s.executeUpdate(sql);

    
    }
    catch(Exception e)
    {
    e.printStackTrace();
    } 
            out.println("<h1 class='p-3 mb-2 bg-danger text-white'>"+sid+"</h1>");
            out.println("<a href=\"ServletPrincipal\" class='btn btn-primary'>Volver al salon</a>");
            out.println("</body>");
            out.println("</html>");  
    }

}