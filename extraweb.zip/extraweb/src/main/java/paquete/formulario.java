/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author eduardo
 */
public class formulario extends HttpServlet 
{
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {

    String pregunta = request.getParameter("user");
    String respuesta = request.getParameter("password");
     response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Servlet</title>");     
           
            out.println("</head>");
            out.println("<body style='    background-color:beige;\n" +
"    font-family:'Arial';\n" +
"    margin: auto;\n" +
"    text-align: center;'>");
    try
    {
    Class.forName("com.mysql.jdbc.Driver");
    Connection db = DriverManager.getConnection("jdbc:mysql://localhost:3306/usuarios","root", "");
    Statement s = db.createStatement();        
    s.executeUpdate("INSERT INTO sesion(user_name,contrasena) VALUES('"+pregunta+"','"+respuesta+"');");
     }
    catch(Exception e)
    {
    e.printStackTrace();
    }
       out.println("<div style='   width: 300px;\n" +
"    margin:0 auto;'>");
            out.println("<h1 style='  text-align: center;\n" +
"    color: darkslategrey;\n" +"text-align: center;\n" +
"    font-size: 28px;\n" +
"    padding: 70px 0 10px 0;'>Usuario creado</h1>");
            out.println("<a style='    width: 100%;\n" +
"    padding: 15px;\n" +
"    background-color:slateblue;\n" +
"    border: 0;\n" +
"    box-sizing: border-box;\n" +
"    cursor: pointer;\n" +
"    font-weight: bold;\n" +
"    font-size: large;\n" +
"    color: seashell;\n" +
"    margin-top: 20px;\n" +
"    appearance: button;\n" +
"    -webkit-appearance: button;\n" +
"    -moz-appearance: button;\n" +
"    text-decoration: none;' href='http://localhost:3000/login'>Volver al CRUD</a>");
                   out.println("</div>");
            out.println("</body>");
            out.println("</html>");  
    
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
