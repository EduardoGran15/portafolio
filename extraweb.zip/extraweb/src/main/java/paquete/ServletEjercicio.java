/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete;
public class ServletEjercicio {

    static void update(ServletEjercicio U) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    static void delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    private int id;
    private String puntoA;
    private String puntoB;
    private String puntoC;
    private String puntoD;

    public ServletEjercicio() {
        this.id = 0;
        this.puntoA = "";
        this.puntoC="";
        this.puntoB="";
        this.puntoD="";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPuntoA() {
        return puntoA;
    }

    public void setPuntoA(String punto) {
        this.puntoA = punto;
    }

    public String getPuntoB() {
        return puntoB;
    }

    public void setPuntoB(String punto) {
        this.puntoB = punto;
    }

    public String getPuntoC() {
        return puntoC;
    }

    public void setPuntoC(String punto) {
        this.puntoC = punto;
    }

    public String getPuntoD() {
        return puntoD;
    }

    public void setPuntoD(String punto) {
        this.puntoD = punto;
    } 
}