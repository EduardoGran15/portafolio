/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete;

/**
 *
 * @author Ariana
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class ServletDelete  extends HttpServlet {
@Override
protected void doGet(HttpServletRequest request, HttpServletResponse response)   
             throws ServletException, IOException {  
                String sid=request.getParameter("id");  
                int id=Integer.parseInt(sid);
                String sql="DELETE FROM reto WHERE id=?";
           try{
               Class.forName("com.mysql.jdbc.Driver");
               Connection db = DriverManager.getConnection("jdbc:mysql://localhost:3306/usuarios","root", "");   
               PreparedStatement stmt=db.prepareStatement(sql);
                    stmt.setInt(1,id);
                    stmt.executeUpdate();
                stmt.close();
              response.sendRedirect("ServletPrincipal");  
           }catch(Exception e){
                e.printStackTrace();
            } 
         
    }  
}
