package paquete;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ServletEdit extends HttpServlet 
{
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String j=request.getParameter("id");
        HttpSession sesion=request.getSession();
       sesion.setAttribute("id", j);
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Editar ejercicio</title>");    
                        out.println("<link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3\" crossorigin=\"anonymous\">");

            out.println("</head>");
            out.println("<body>");
            out.println("<h1 class='p-3 mb-2 bg-danger text-white'>Editar ejercicio</h1>");
            out.println("<form action='ServletActualiza' method='get' class='form-group'>"); 
            out.println("<label>puntoA: </label><input name='puntoA' type='text' class=\"form-control\" /> <br />"); 
            out.println("<label>puntoB: </label><input name='puntoB' type='text' class=\"form-control\"/> <br />");

            out.println("<input type='submit' class=\"btn btn-primary\" />");                                                
            out.println("</form>");                        
            out.println("</body>");
            out.println("</html>");  
    }

}