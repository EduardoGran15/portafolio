package paquete;
import java.util.ArrayList;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ServletPrincipal extends HttpServlet 
{
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {  response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Servlet</title>"); 
            out.println("<link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3\" crossorigin=\"anonymous\">");
            out.println("</head>");
            out.println("<body>");
              out.println("<h1 class='p-3 mb-2 bg-danger text-white'>Bienvenido a este salon interactivo</h1><br />");
                    out.println("<a href='http://localhost:3000/login' class='btn btn-light'>Cerrar sesion</a> <br><br>");
               out.println("<a href='ServleteCreate' class='btn btn-info'>Crear nuevo ejercicio</a> <br><br>");
               out.println("<table class='table'>");
            out.println("<tr>");
            out.println("<td>ID pregunta</td>");
            out.println("<td>Acciones</td>");
            out.println("</tr>");
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection db = DriverManager.getConnection("jdbc:mysql://localhost:3306/usuarios","root", "");
            Statement s = db.createStatement();
            String sql = "select * from ejercicio";
        ResultSet users= s.executeQuery(sql);
         while(users.next()){
                ServletEjercicio usuario = new ServletEjercicio();
                usuario.setId(users.getInt("id"));
                int h=usuario.getId();
                int g=usuario.getId();
                out.println("<tr>");
                out.println("<td>"+usuario.getId()+"</td>");
                out.println("<td><a href='ServletRead?id="+h+"' class='btn btn-primary'>Leer Ejercicio</a></td>");
                out.println("<td><a href='ServletEdit?id="+g+"' class='btn btn-secondary'>Modificar Ejercicio</a></td>");   
                out.println("<td><a href='ServletDelete?id="+h+"' class='btn btn-success'>Eliminar Ejercicio</a></td>");
                   out.println("<td><a href='ServleteTrabajo?id="+h+"' class='btn btn-danger'>Realizar Ejercicio</a></td>");
                out.println("</tr>");
            }
              }catch(Exception ex){
            
        }
            out.println("</table>");            
            out.println("</body>");
            out.println("</html>");
      
    }
}
 