-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 25-06-2021 a las 04:37:08
-- Versión del servidor: 10.4.18-MariaDB
-- Versión de PHP: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `animal`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `adoptable`
--

CREATE TABLE `adoptable` (
  `Raza` varchar(30) DEFAULT NULL,
  `comportamiento` varchar(50) DEFAULT NULL,
  `enfermedades` varchar(50) DEFAULT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  `ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `adoptable`
--

INSERT INTO `adoptable` (`Raza`, `comportamiento`, `enfermedades`, `nombre`, `ID`) VALUES
('coker', 'miedoso', 'tifoidea', 'lulu', 1),
('chihuahua', 'muerde niños', 'piojos', 'cachito', 3),
('bordercoli', 'jugueton', 'parasitos intestinales', 'copito', 4),
('bulldog', 'jugueton', 'parasitos intestinales', 'coco', 5),
('galgo', 'timido', 'ninguna', 'rayo', 6),
('doberman', 'timido', 'ninguna', 'luis', 7),
('golden', 'agresivo', 'ninguna', 'pepe', 8),
('golden cafe', 'tranquilo', 'ninguna', 'chocolate', 9),
('corgi', 'jugueton', 'piojos', 'blue', 11),
('beagle', 'jugueton', 'piojos', 'green', 12),
('salchicha', 'jugueton', 'moquillo', 'chealsey', 13),
('salchicha', 'jugueton', 'moquillo', 'rian', 14),
('salchicha', 'jugueton', 'moquillo', 'biran', 15);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `animales`
--

CREATE TABLE `animales` (
  `ID` int(11) NOT NULL,
  `Especie` varchar(30) DEFAULT NULL,
  `Peso` float DEFAULT NULL,
  `Talla` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inquilino`
--

CREATE TABLE `inquilino` (
  `ID` int(11) NOT NULL,
  `nombrePrestador` varchar(30) DEFAULT NULL,
  `direccion` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mascota`
--

CREATE TABLE `mascota` (
  `nombreDueno` varchar(30) DEFAULT NULL,
  `numeroContacto` varchar(15) DEFAULT NULL,
  `nombreMascota` varchar(30) DEFAULT NULL,
  `direccion` varchar(30) DEFAULT NULL,
  `fecha` varchar(30) DEFAULT NULL,
  `ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `adoptable`
--
ALTER TABLE `adoptable`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `animales`
--
ALTER TABLE `animales`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `inquilino`
--
ALTER TABLE `inquilino`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `mascota`
--
ALTER TABLE `mascota`
  ADD PRIMARY KEY (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
