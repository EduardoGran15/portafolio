/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author eduardo
 */
public class Adoptable extends Animal{// implements InquilinoProvicional {
    private String Raza;
    private String comportamiento;
    private String []enfermedades;
    private String nombre;
    private String nombreHospedante;
    private String nombreDireccion;
    

    public String getRaza() {
        return Raza;
    }

    public void setRaza(String Raza) {
        this.Raza = Raza;
    }

    public String getComportamiento() {
        return comportamiento;
    }

    public void setComportamiento(String comportamiento) {
        this.comportamiento = comportamiento;
    }

    public String[] getEnfermedades() {
        return enfermedades;
    }

    public void setEnfermedades(String[] enfermedades) {
        this.enfermedades = enfermedades;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
     public void setPrestador(String nombre,String direccion){
         this.conectarBD();
         try{String sql="insert into inquilino (nombrePrestador,direccion) values('"+nombre+"',"+"'"+ direccion+ "');";
         java.sql.Statement st = (java.sql.Statement) this.getCon().createStatement();
         int i=st.executeUpdate(sql);
           st.close();
        }catch (Exception ex) {
            Logger.getLogger(datosCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
          JOptionPane.showMessageDialog(null, "Vienenido al programa de inquilino, donde prestas tu casa a un perrito sin hogar ");
         
     }
   
    
}
