/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

/**
 *
 * @author eduardo
 */
public class Doctor{
    private String []pacientes;
    private String consultorio;
    private String especialidad;

    public String[] getPacientes() {
        return pacientes;
    }

    public void setPacientes(String[] pacientes) {
        this.pacientes = pacientes;
    }

    public String getConsultorio() {
        return consultorio;
    }

    public void setConsultorio(String consultorio) {
        this.consultorio = consultorio;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }
    

    @Override
    public String toString() {
        return super.toString()+"Pacientes: "+this.getPacientes()+"\n"+"Consultorio: "+"\n"+this.getConsultorio()+"\n"+"Especialidad: "+"\n"+this.getEspecialidad(); //To change body of generated methods, choose Tools | Templates.
    }

}
