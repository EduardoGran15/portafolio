/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author eduardo
 */
public class operacionesAdopcion extends JPanel{
    private JTextField nombre;
    private JButton generarAdopcion;
    private JLabel mensaje;
    private String co;
    
     private com.mysql.jdbc.Connection con;
    private com.mysql.jdbc.Statement st;
    public operacionesAdopcion(){
        initComponents();
     
    }
    public void initComponents(){
        this.setLayout(new GridLayout(1,3));
        nombre=new JTextField();
        generarAdopcion=new JButton("generar la adopcion");
        mensaje=new JLabel("  ingrese el nombre de la mascota");
        ActionListener adop=new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                Singin s=new Singin(nombre.getText());
                
            }
        };
   
         generarAdopcion.addActionListener(adop);
        this.add(nombre);
        this.add(generarAdopcion);
        this.add(mensaje);
       
    }
     private void eliminarAdoptado(String nombre){
        try { String sql="DELETE  FROM adoptable WHERE nombre='"+nombre+"';";
            java.sql.Statement st = (java.sql.Statement) con.createStatement();
            int i= st.executeUpdate(sql);  
st.close();
        } catch (SQLException ex) {
            Logger.getLogger(datosCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
    
}
