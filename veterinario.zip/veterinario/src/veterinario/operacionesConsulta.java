/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author eduardo
 */
public class operacionesConsulta extends JPanel {
       private JTextField nss;
    private JButton generarConsulta;
    private JLabel mensaje;
    private String co;
    private int npacientes;
    private Container ce;
    
    
     private com.mysql.jdbc.Connection con;
    private com.mysql.jdbc.Statement st;
    public operacionesConsulta(Container ce){
        this.ce=ce;
        initComponents();
              try {
         Class.forName("com.mysql.jdbc.Driver");
          con = (com.mysql.jdbc.Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/Animal","root",""); 
          System.out.printf("conexion exitosa");
     } catch (ClassNotFoundException ex) {
         Logger.getLogger(Singin.class.getName()).log(Level.SEVERE, null, ex);
     }   catch (SQLException ex) {
             Logger.getLogger(paginaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
         }
     
    }
    public void initComponents(){
        this.setLayout(new GridLayout(1,3));
        nss=new JTextField();
        generarConsulta=new JButton("Gnerar Consulta");
        mensaje=new JLabel("  ingrese el nss de el medico");
        ActionListener adop=new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
                Singin s=new Singin(Integer.parseInt(nss.getText()));
                ce.setVisible(false);
                eliminarPaciente(nss.getText());
            }
        };
   
         generarConsulta.addActionListener(adop);
        this.add(nss);
        this.add(generarConsulta);
        this.add(mensaje);
       
    }

     private void eliminarPaciente(String nss){
         String npacientes="";
         int numeroSS=Integer.parseInt(nss);
        try { String sql="SELECT pacientes FROM doctores  WHERE nss="+numeroSS+";";
            java.sql.Statement st = (java.sql.Statement) con.createStatement();
            ResultSet rs = st.executeQuery(sql); 
            while(rs.next()){
                npacientes=rs.getString("pacientes");
            }
rs.close();
st.close();
        } catch (SQLException ex) {
            Logger.getLogger(datosCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.npacientes=Integer.parseInt(npacientes);
        this.npacientes=this.npacientes+1;
        try{String sql="UPDATE  doctores set pacientes='"+this.npacientes+"'"+"Where nss='"+nss+"';";
         java.sql.Statement st = (java.sql.Statement) con.createStatement();
         int i=st.executeUpdate(sql);
           st.close();
        }catch (Exception ex) {
            Logger.getLogger(datosCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        ce.setVisible(true);
     }
     
    
}
