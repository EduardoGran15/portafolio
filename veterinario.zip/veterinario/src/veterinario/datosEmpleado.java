/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author eduardo
 */
public class datosEmpleado extends JPanel{
       private Empleado client;
    private FlujoEntrada Archivo;
    private FlujoSalida Archivo1;
      private JTextField nss;
    private JTextField apMat;
      private JTextField apPat;
      private JTextField nombre;
      private JTextField puesto;
        private Object [] cli;
        private Object [] regist;
        private Container cliente;
         public datosEmpleado(){
        initComponents();
      
    }
           private void initComponents(){
                JButton enviar=new JButton();
          this.setLayout(new GridLayout(8,2));
         client=new Empleado();
         regist=Archivo1.leerObjetos();
         cli=new Object[regist.length+1];
         for (int i = 0; i < regist.length; i++) {
            cli[i]=regist[i];
        }
       nombre=new JTextField(10);
       nss=new JTextField(10);
        apPat=new JTextField(10);
        apMat=new JTextField(10);
        puesto=new JTextField(10);
         
          ActionListener obtenerData=new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
              client.setNombre(nombre.getText());
              client.setApPat(apPat.getText());
              client.setApMat(apMat.getText());
              client.setPuesto(puesto.getText());
              client.setNss(nss.getText());
                if (nombre.getText().equals("") || apPat.getText().equals("") || apMat.getText().equals("") || puesto.getText().equals("") || nss.getText().equals("") ) {
                     JOptionPane.showMessageDialog(null, "Faltan datos");
                }else{
             
            
              for(Object obj:cli){
                  System.out.println((Empleado)obj);
                  
              }
            }
            }
        };
          enviar.addActionListener(obtenerData);
       enviar.setText("enviar");
      
       add(new JLabel("Nombre"));
       add(nombre);
       add(new JLabel("Apellido Paterno"));
       add(apPat);
         add(new JLabel("Apellido Materno"));
       add(apMat);
         add(new JLabel("Direccion"));
       add(nss);
         add(new JLabel("numero de contacto"));
       add(puesto);
      add(enviar);
      
       
       
       
    }
           }
            

