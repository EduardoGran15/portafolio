/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author eduardo
 */
public class FlujoSalida {
      private final String archivo;
    private ObjectInputStream lecturaClase;
    private FileInputStream File;
    public FlujoSalida(String nombre){
this.archivo=nombre;
        lecturaClase=null;
File=null;
}
    private void abrirFlujo(){
            try {
                File=new FileInputStream(archivo);
                   lecturaClase=new ObjectInputStream(File);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(FlujoSalida.class.getName()).log(Level.SEVERE, null, ex);
            }
            catch (IOException ex) {
                Logger.getLogger(FlujoSalida.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    private void cerrarFlujo(){
        if(lecturaClase!=null){
            try {
                lecturaClase.close();
            } catch (IOException ex) {
                Logger.getLogger(FlujoSalida.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    public Object [] leerObjetos(){
        abrirFlujo();
        Object[] listaObjetos=null;
        int contador=0;
        try{
        Object obj=new Object();
   while(true){
       if(File.available()!=0){
           obj=lecturaClase.readObject();
           contador++;
       }else{
           break;
       }
       
   }
   cerrarFlujo();
   abrirFlujo();
   listaObjetos=new Object[contador];
   contador=0;
   while(true){
       if(File.available()!=0){
          
               obj=lecturaClase.readObject();
           
           listaObjetos[contador]=obj;
           contador++;
       }else{
           break;
       }
   }
        }catch(EOFException eof){
              Logger.getLogger(FlujoEntrada.class.getName()).log(Level.SEVERE, null, eof);
        }
        catch (IOException ex) {
                Logger.getLogger(FlujoEntrada.class.getName()).log(Level.SEVERE, null, ex);
            }catch (ClassNotFoundException ex) {
               Logger.getLogger(FlujoSalida.class.getName()).log(Level.SEVERE, null, ex);
           }finally{
            cerrarFlujo();
        }
    return listaObjetos;    
}
}
