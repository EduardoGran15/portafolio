/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;


import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author eduardo
 */
public class opcionesPrincipales extends JPanel {
    private JButton adoptar;
    private JButton consulta;
   
    private JButton Login;
    private JLabel usuario;
    private paginaPrincipal pe;
    private DefaultTableModel datosAdoptables;
    public opcionesPrincipales(paginaPrincipal pi){
        initComponents();
        pe=pi;
    }
    public void initComponents(){
   
        ActionListener log=new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
              login P=new login(pe);
             pe.dispose();//To change body of generated methods, choose Tools | Templates.
            }
        };
           
       ActionListener tab=new ActionListener(){

           @Override
           public void actionPerformed(ActionEvent ae) {
               pe.setTabla();
               pe.dispose();
               pe.setVisible(true);
           }
           
       };
         ActionListener tab2=new ActionListener(){

           @Override
           public void actionPerformed(ActionEvent ae) {
               pe.setDoctoresTabla();
               pe.dispose();
               pe.setVisible(true);
           }
           
       };
        usuario=new JLabel("usuario");
        adoptar=new JButton("Adoptar");
       
        consulta=new JButton("Consulta");
       
        Login=new JButton("Login");
        
        Login.addActionListener(log);
        adoptar.addActionListener(tab);
        consulta.addActionListener(tab2);
      this.setLayout(new GridLayout(1,5));
      add(adoptar);
      
      add(consulta);
    
      
      add(Login);
      add(usuario);
      
    }

    public  String getUsuario() {
        return usuario.getText();
    }
    public void setUsuario(String user){
        usuario.setText(user);
    }
  
}
