/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author eduardo
 */
public class datosCliente extends JPanel {
    private Cliente client;
    private FlujoEntrada Archivo;
    private FlujoSalida Archivo1;
      private JTextField nombre;
    private JTextField apellidoPaterno;
      private JTextField apellidoMaterno;
      private JTextField Direccion;
        private JTextField numeroContacto;
        private Object [] cli;
        private Object [] regist;
        private Container cliente;
        private com.mysql.jdbc.Connection con;
        private com.mysql.jdbc.Statement st;
     private Singin sg;
    public datosCliente(Container cliente,Singin sg){
        initComponents();
        this.cliente=cliente;
        this.sg=sg;
    }
    public datosCliente(Singin sg){
        initComponents(sg);
    }
        public datosCliente(Singin sg,int i){
        initComponents(sg,i);
    }
    public datosCliente( String g){
        initComponents(g);
    }
    public void initComponents(){
         JButton enviar=new JButton();
          this.setLayout(new GridLayout(8,2));
         client=new Cliente();
         Archivo1=new FlujoSalida("C:\\Users\\eduardo\\Documents\\NetBeansProjects\\veterinario\\Dueño.obj");
         Archivo=new FlujoEntrada("C:\\Users\\eduardo\\Documents\\NetBeansProjects\\veterinario\\Dueño.obj");
         regist=Archivo1.leerObjetos();
         cli=new Object[regist.length+1];
         for (int i = 0; i < regist.length; i++) {
            cli[i]=regist[i];
        }
       nombre=new JTextField(10);
       apellidoPaterno=new JTextField(10);
        apellidoMaterno=new JTextField(10);
        Direccion=new JTextField(10);
         numeroContacto=new JTextField(10);
     
          ActionListener obtenerData=new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
              client.setNombre(nombre.getText());
              client.setApPat(apellidoPaterno.getText());
              client.setApMat(apellidoMaterno.getText());
              client.setDireccion(Direccion.getText());
              client.setTelContacto(numeroContacto.getText());
                if (nombre.getText().equals("") || apellidoPaterno.getText().equals("") || apellidoMaterno.getText().equals("") || Direccion.getText().equals("") || numeroContacto.getText().equals("") ) {
                     JOptionPane.showMessageDialog(null, "Faltan datos");
                }else{
              cli[regist.length]=client;
              Archivo.escribirObjetos(cli);
              cliente.setVisible(true);
              cliente.setName(nombre.getText());
              sg.setVisible(false);
              for(Object obj:cli){
                  System.out.println((Cliente)obj);
              }
            }
            }
        };
          enviar.addActionListener(obtenerData);
       enviar.setText("enviar");
      
       add(new JLabel("Nombre"));
       add(nombre);
       add(new JLabel("Apellido Paterno"));
       add(apellidoPaterno);
         add(new JLabel("Apellido Materno"));
       add(apellidoMaterno);
         add(new JLabel("Direccion"));
       add(Direccion);
         add(new JLabel("numero de contacto"));
       add(numeroContacto);
      add(enviar);
      
       
       
       
    }
     public void initComponents( String g){
                  
    
        try {
         Class.forName("com.mysql.jdbc.Driver");
          con = (com.mysql.jdbc.Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/Animal","root",""); 
          System.out.printf("conexion exitosa");
     } catch (ClassNotFoundException ex) {
         Logger.getLogger(Singin.class.getName()).log(Level.SEVERE, null, ex);
     }   catch (SQLException ex) {
             Logger.getLogger(paginaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
         }
         JButton enviar=new JButton();
          this.setLayout(new GridLayout(8,2));
         client=new Cliente();
         Archivo1=new FlujoSalida("C:\\Users\\eduardo\\Documents\\NetBeansProjects\\veterinario\\Dueño.obj");
         Archivo=new FlujoEntrada("C:\\Users\\eduardo\\Documents\\NetBeansProjects\\veterinario\\Dueño.obj");
         regist=Archivo1.leerObjetos();
         cli=new Object[regist.length+1];
         for (int i = 0; i < regist.length; i++) {
            cli[i]=regist[i];
        }
       nombre=new JTextField(10);
       apellidoPaterno=new JTextField(10);
        apellidoMaterno=new JTextField(10);
        Direccion=new JTextField(10);
         numeroContacto=new JTextField(10);
     
          ActionListener obtenerData2=new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
              client.setNombre(nombre.getText());
              client.setApPat(apellidoPaterno.getText());
              client.setApMat(apellidoMaterno.getText());
              client.setDireccion(Direccion.getText());
              client.setTelContacto(numeroContacto.getText());
                if (nombre.getText().equals("") || apellidoPaterno.getText().equals("") || apellidoMaterno.getText().equals("") || Direccion.getText().equals("") || numeroContacto.getText().equals("") ) {
                     JOptionPane.showMessageDialog(null, "Faltan datos");
                }else{
              cli[regist.length]=client;
              Archivo.escribirObjetos(cli);
               JOptionPane.showMessageDialog(null, "Adopcion concluida para "+g);
               eliminarAdoptado(g);
              for(Object obj:cli){
                  System.out.println((Cliente)obj);
                  
              }
            }
            }
        };
          enviar.addActionListener(obtenerData2);
       enviar.setText("enviar");
      
       add(new JLabel("Nombre"));
       add(nombre);
       add(new JLabel("Apellido Paterno"));
       add(apellidoPaterno);
         add(new JLabel("Apellido Materno"));
       add(apellidoMaterno);
         add(new JLabel("Direccion"));
       add(Direccion);
         add(new JLabel("numero de contacto"));
       add(numeroContacto);
      add(enviar);
    }
     private void eliminarAdoptado(String nombre){
        try { String sql="DELETE  FROM adoptable WHERE nombre='"+nombre+"';";
            java.sql.Statement st = (java.sql.Statement) con.createStatement();
            int i= st.executeUpdate(sql);  
st.close();
        } catch (SQLException ex) {
            Logger.getLogger(datosCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
     }
         public void initComponents(Singin sg){
         JButton enviar=new JButton();
          this.setLayout(new GridLayout(8,2));
         client=new Cliente();
         Archivo1=new FlujoSalida("C:\\Users\\eduardo\\Documents\\NetBeansProjects\\veterinario\\Dueño.obj");
         Archivo=new FlujoEntrada("C:\\Users\\eduardo\\Documents\\NetBeansProjects\\veterinario\\Dueño.obj");
         regist=Archivo1.leerObjetos();
         cli=new Object[regist.length+1];
         for (int i = 0; i < regist.length; i++) {
            cli[i]=regist[i];
        }
       nombre=new JTextField(10);
       apellidoPaterno=new JTextField(10);
        apellidoMaterno=new JTextField(10);
        Direccion=new JTextField(10);
         numeroContacto=new JTextField(10);
     
          ActionListener obtenerData=new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
              client.setNombre(nombre.getText());
              client.setApPat(apellidoPaterno.getText());
              client.setApMat(apellidoMaterno.getText());
              client.setDireccion(Direccion.getText());
              client.setTelContacto(numeroContacto.getText());
                if (nombre.getText().equals("") || apellidoPaterno.getText().equals("") || apellidoMaterno.getText().equals("") || Direccion.getText().equals("") || numeroContacto.getText().equals("") ) {
                     JOptionPane.showMessageDialog(null, "Faltan datos");
                }else{
              cli[regist.length]=client;
              Archivo.escribirObjetos(cli);
              sg.setVisible(false);
              for(Object obj:cli){
                  System.out.println((Cliente)obj);
              }
            }
            }
        };
          enviar.addActionListener(obtenerData);
       enviar.setText("enviar");
       add(new JLabel("Nombre"));
       add(nombre);
       add(new JLabel("Apellido Paterno"));
       add(apellidoPaterno);
         add(new JLabel("Apellido Materno"));
       add(apellidoMaterno);
         add(new JLabel("Direccion"));
       add(Direccion);
         add(new JLabel("numero de contacto"));
       add(numeroContacto);
      add(enviar);
        
    }
           public void initComponents(Singin sg,int j){
         JButton enviar=new JButton();
          this.setLayout(new GridLayout(8,2));
         client=new Cliente();
         Archivo1=new FlujoSalida("C:\\Users\\eduardo\\Documents\\NetBeansProjects\\veterinario\\Dueño.obj");
         Archivo=new FlujoEntrada("C:\\Users\\eduardo\\Documents\\NetBeansProjects\\veterinario\\Dueño.obj");
         regist=Archivo1.leerObjetos();
         cli=new Object[regist.length+1];
         for (int i = 0; i < regist.length; i++) {
            cli[i]=regist[i];
        }
       nombre=new JTextField(10);
       apellidoPaterno=new JTextField(10);
        apellidoMaterno=new JTextField(10);
        Direccion=new JTextField(10);
         numeroContacto=new JTextField(10);
     insersionConsulta insert=new insersionConsulta();
          ActionListener obtenerData=new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {
              client.setNombre(nombre.getText());
              client.setApPat(apellidoPaterno.getText());
              client.setApMat(apellidoMaterno.getText());
              client.setDireccion(Direccion.getText());
              client.setTelContacto(numeroContacto.getText());
                if (nombre.getText().equals("") || apellidoPaterno.getText().equals("") || apellidoMaterno.getText().equals("") || Direccion.getText().equals("") || numeroContacto.getText().equals("") ) {
                     JOptionPane.showMessageDialog(null, "Faltan datos");
                }else{
              cli[regist.length]=client;
              Archivo.escribirObjetos(cli);
              sg.setVisible(false);
              for(Object obj:cli){
                  System.out.println((Cliente)obj);
              }
              insert.conectar();
              insert.registrarConsulta(j, nombre.getText());
            }
            }
        };
          enviar.addActionListener(obtenerData);
       enviar.setText("enviar");
       add(new JLabel("Nombre"));
       add(nombre);
       add(new JLabel("Apellido Paterno"));
       add(apellidoPaterno);
         add(new JLabel("Apellido Materno"));
       add(apellidoMaterno);
         add(new JLabel("Direccion"));
       add(Direccion);
         add(new JLabel("numero de contacto"));
       add(numeroContacto);
      add(enviar);
        
    }
         public String getNombre(){
             return this.nombre.getText();
         }
         public String getDireccion(){
             return this.Direccion.getText();
         }
}
