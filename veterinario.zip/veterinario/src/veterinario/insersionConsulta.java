/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author eduardo
 */
public class insersionConsulta {
     com.mysql.jdbc.Connection con;
     public void conectar(){
          try {
         Class.forName("com.mysql.jdbc.Driver");
          con = (com.mysql.jdbc.Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/Animal","root",""); 
          System.out.printf("conexion exitosa");
     } catch (ClassNotFoundException ex) {
         Logger.getLogger(Singin.class.getName()).log(Level.SEVERE, null, ex);
     }   catch (SQLException ex) {
             Logger.getLogger(paginaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
         }
     }
         public void registrarConsulta(int numerodoc,String nombreDueño){
        
         try{String sql="insert into consulta (nssDoctor,nombreMascota) values("+numerodoc+","+"'"+ nombreDueño+ "');";
         java.sql.Statement st = (java.sql.Statement) con.createStatement();
         int i=st.executeUpdate(sql);
           st.close();
        }catch (Exception ex) {
            Logger.getLogger(datosCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
