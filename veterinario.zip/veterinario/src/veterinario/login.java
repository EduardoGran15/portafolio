/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

import java.awt.BorderLayout;
import static java.awt.Color.BLACK;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import javafx.scene.layout.Border;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;


/**
 *
 * @author eduardo
 */
public class login extends JFrame{
    private datos d;
    private mouseListener m;
   
        public login(paginaPrincipal pi) {
        
          this.setSize(320,300);
          d=new datos(pi,this);
          initComponents();
    }
        
    private void initComponents() {

        Container contenedor=this.getContentPane();
        contenedor.setLayout(new BorderLayout());
        ImageIcon imagen=new ImageIcon("src/imagenes/usuario_sin_imagen.png");
              JLabel label=new JLabel();
              m=new mouseListener();
              label.setSize(100,100);
        Icon icon=new ImageIcon(imagen.getImage().getScaledInstance(label.getWidth(),label.getHeight(),Image.SCALE_DEFAULT));
  label.setIcon(icon);
  JLabel label1=new JLabel();
 
  label1.setText("si no esta registrado, clic aqui");
  label1.setFont(new Font("Arial", Font.BOLD, 13));
        this.add(label,BorderLayout.WEST);
        this.add(label1,BorderLayout.EAST);
        this.add(d,BorderLayout.SOUTH);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        this.addWindowListener(new controladorCierre());
         this.setResizable(false);
        label1.addMouseListener(new mouseListener(){
                @Override
    public void mouseClicked(MouseEvent me) {
         contenedor.setVisible(false);
         Singin s=new Singin(contenedor);
         
    }
        });
    
       
   }
}
