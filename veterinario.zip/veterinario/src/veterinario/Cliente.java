/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

import java.io.Serializable;

/**
 *
 * @author eduardo
 */
public class Cliente implements Serializable{
        static final long serialVersionUID=3L;
    private String nombre;
    private String apPat;
    private String apMat;
    private String direccion;
    private String telContacto;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApPat() {
        return apPat;
    }

    public void setApPat(String apPat) {
        this.apPat = apPat;
    }

    public String getApMat() {
        return apMat;
    }

    public void setApMat(String apMat) {
        this.apMat = apMat;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelContacto() {
        return telContacto;
    }

    public void setTelContacto(String telContacto) {
        this.telContacto = telContacto;
    }


    @Override
    public String toString() {
       return "nombre: "+this.nombre+"\n"+"apellidoPaterno: "+this.apPat;
    }


    public boolean equals(String a,String b) {
        return a.equals(this.nombre) && b.equals(this.apPat);
    }

    
    
}
