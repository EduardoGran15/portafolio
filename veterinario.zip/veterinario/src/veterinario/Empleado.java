/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

import java.io.Serializable;

/**
 *
 * @author eduardo
 */
public class Empleado implements Serializable {
    static final long serialVersionUID=3L;
    private String nss;
    private String nombre;
    private String apPat;
    private String apMat;
private String puesto;    

    public String getNss() {
        return nss;
    }

    public void setNss(String nss) {
        this.nss = nss;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApPat() {
        return apPat;
    }

    public void setApPat(String apPat) {
        this.apPat = apPat;
    }

    public String getApMat() {
        return apMat;
    }

    public void setApMat(String apMat) {
        this.apMat = apMat;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }
    

    @Override
    public String toString() {
       return "nss: "+this.nss+"nombre: "+this.nombre; //To change body of generated methods, choose Tools | Templates.
    }

    
}
