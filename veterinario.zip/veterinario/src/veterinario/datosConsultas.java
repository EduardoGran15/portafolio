/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

import java.awt.Dimension;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author eduardo
 */
public class datosConsultas extends JPanel {
        public DefaultTableModel tabla;
    public JTable tablaVista;
    public datosConsultas(){
    initcomponents();
}
    
   public void initcomponents(){
       String []datos={"NSS","Npacientes","Conultorio","Especialidad"};
        tabla=new DefaultTableModel(null,datos);
       String []p={"NSS","Npacientes","Conultorio","Especialidad"};
       tabla.addRow(p);
        tablaVista=new JTable(tabla);
       tablaVista.setBounds(30, 30, 500, 300);
       this.setLayout(null);
       this.setPreferredSize(new Dimension(100,100));
       this.add(tablaVista);
       this.setVisible(true);
 }
}
