/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author eduardo
 */
public class paginaPrincipal extends JFrame {
    private opcionesPrincipales p;
    private operacionesAdopcion k;
    private operacionesConsulta h;
    private datosConsultas d;
    private  datosAdoptables s;
 
     private JLabel  label;
      com.mysql.jdbc.Connection con;
    com.mysql.jdbc.Statement st;
    public paginaPrincipal(String titulo){
        super(titulo);
        p=new opcionesPrincipales(this);
        k=new operacionesAdopcion();
        h=new operacionesConsulta(this);
        this.setSize(700, 500);
initcomponentns();
    }
    public void initcomponentns(){    
         Container contenedor=this.getContentPane();
        contenedor.setLayout(new BorderLayout());
         
     s=new datosAdoptables ();
     d=new datosConsultas();
     ImageIcon imagen=new ImageIcon("src/imagenes/inicio.jpg");
            label=new JLabel();
              label.setSize(700,300);
        Icon icon=new ImageIcon(imagen.getImage().getScaledInstance(label.getWidth(),label.getHeight(),Image.SCALE_DEFAULT));
  label.setIcon(icon);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        this.add(p, BorderLayout.NORTH);
     this.add(label,BorderLayout.CENTER);
        this.addWindowListener(new controladorCierre());
         this.setResizable(false);
             try {
         Class.forName("com.mysql.jdbc.Driver");
          con = (com.mysql.jdbc.Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/Animal","root",""); 
          System.out.printf("conexion exitosa");
     } catch (ClassNotFoundException ex) {
         Logger.getLogger(Singin.class.getName()).log(Level.SEVERE, null, ex);
     }   catch (SQLException ex) {
             Logger.getLogger(paginaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
         }

    }public void setLog(String log){
        p.setUsuario(log);
    }
    public void setTabla(){
        this.remove(label);
        
       String []fila=new String[4];
       
        try {
            String sql="SELECT Raza,comportamiento,enfermedades,nombre FROM adoptable;";
java.sql.Statement st = (java.sql.Statement) con.createStatement();
ResultSet rs = st.executeQuery(sql);
while (rs.next()) {
fila[0] = rs.getString("Raza");
fila[1] = rs.getString("comportamiento");
fila[2] = rs.getString("enfermedades");
fila[3] = rs.getString("nombre");


s.tabla.addRow(fila);
}
s.tablaVista.setModel(s.tabla);

rs.close();
st.close();
} catch (Exception ex) {
JOptionPane.showMessageDialog(null, ex);
}
                   
         this.add(s,BorderLayout.CENTER);
    this.add(k,BorderLayout.SOUTH);
    }
    public void setDoctoresTabla(){
         this.remove(label);
        
       String []fila=new String[4];
       
        try {
            String sql="SELECT * FROM doctores;";
java.sql.Statement st = (java.sql.Statement) con.createStatement();
ResultSet rs = st.executeQuery(sql);
while (rs.next()) {
fila[0] = rs.getString("nss");
fila[1] = rs.getString("pacientes");
fila[2] = rs.getString("consultorio");
fila[3] = rs.getString("especialidad");
if(fila[1].equals("10")){
}else{
d.tabla.addRow(fila);}
}
d.tablaVista.setModel(d.tabla);

rs.close();
st.close();
} catch (Exception ex) {
JOptionPane.showMessageDialog(null, ex);
}
                   
         this.add(d,BorderLayout.CENTER);
    this.add(h,BorderLayout.SOUTH);
        
    }
}

