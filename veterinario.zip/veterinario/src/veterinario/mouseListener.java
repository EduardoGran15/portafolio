/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 *
 * @author eduardo
 */
public class mouseListener implements MouseListener {

    @Override
    public void mouseClicked(MouseEvent me) {
         System.out.println("si salio");
         
    }

    @Override
    public void mousePressed(MouseEvent me) {
       //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseEntered(MouseEvent me) {
        //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void mouseExited(MouseEvent me) {
        //To change body of generated methods, choose Tools | Templates.
    }

}
