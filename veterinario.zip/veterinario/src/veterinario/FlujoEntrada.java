/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author eduardo
 */
public class FlujoEntrada {
      private final String archivo;
    private ObjectOutputStream entradaClase;
    private FileOutputStream File;
    public FlujoEntrada(String nombre){
        this.archivo=nombre;
entradaClase=null;
File=null;
    }    
    private void abrirFlujo(){
                try {
            File=new FileOutputStream(archivo);
             entradaClase=new ObjectOutputStream(File);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FlujoEntrada.class.getName()).log(Level.SEVERE, null, ex);
        }
     catch (IOException ex) {
            Logger.getLogger(FlujoEntrada.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void cerrarFlujo(){
        if(entradaClase!=null){
            try {
                entradaClase.close();
            } catch (IOException ex) {
                Logger.getLogger(FlujoEntrada.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    public void escribirObjetos(Object [] lista) {
        abrirFlujo();
        
            try {
                for (Object obj:lista) {
                entradaClase.writeObject(obj);}
            } catch (IOException ex) {
                Logger.getLogger(FlujoEntrada.class.getName()).log(Level.SEVERE, null, ex);
            }
            finally {
                cerrarFlujo();
            }
        

   
    }
}
