/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author eduardo
 */
public class datos extends JPanel{
    private JTextField usuario;
    private JTextField password;
    private FlujoEntrada Archivo;
    private FlujoSalida Archivo1;
    private Object [] clientes;
  
   private paginaPrincipal pe;
private login lg;
    public datos(paginaPrincipal pi,login lg){
        initComponents();
        pe=pi;
        this.lg=lg;
    }
    public void initComponents(){
       
         JButton enviar=new JButton();
         JButton cancelar=new JButton("cancelar");
       usuario=new JTextField(10);
       password=new JTextField(10);

       Archivo1=new FlujoSalida("C:\\Users\\eduardo\\Documents\\NetBeansProjects\\veterinario\\Dueño.obj");
       clientes=Archivo1.leerObjetos();
       ActionListener obtenerData=new ActionListener() {
           
            @Override
            public void actionPerformed(ActionEvent ae) {
            
                for(Object obj:clientes){
                    if(((Cliente)obj).equals(usuario.getText(),password.getText())){
                        JOptionPane.showMessageDialog(null, "vienvenido");
                        pe.setLog(usuario.getText());
                        pe.setVisible(true);
                        lg.setVisible(false);
                    
                    }
                }
            }
        };
      
      
       ActionListener cancela=new ActionListener() {

             @Override
             public void actionPerformed(ActionEvent ae) {
              pe.setVisible(true);
                        lg.setVisible(false);   //To change body of generated methods, choose Tools | Templates.
             }
         };
     
       enviar.setText("verificar");
       this.setLayout(new GridLayout(3,2));
       add(new JLabel("Ingrese su usuario"));
       add(usuario);
       add(new JLabel("Ingrese su contraseña"));
       add(password);
     enviar.addActionListener(obtenerData);
     cancelar.addActionListener(cancela);
      add(enviar);
      
      add(cancelar);
      
      
       
       
       
    }
     
}
