/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author eduardo
 */
public class empleadosRegistro extends JFrame {
     private datosEmpleado d;
          private mouseListener m;
         private Container ea;
        public empleadosRegistro() {
          
          this.setSize(340,600);
       
          
          initComponents();
        }
         private void initComponents() {
  
        Container contenedor=this.getContentPane();
        contenedor.setLayout(new BorderLayout());
        d=new datosEmpleado();
             ImageIcon imagen=new ImageIcon("src/imagenes/beagle.jpg");
              JLabel label=new JLabel();
              label.setSize(340,300);
        Icon icon=new ImageIcon(imagen.getImage().getScaledInstance(label.getWidth(),label.getHeight(),Image.SCALE_DEFAULT));
  label.setIcon(icon);
 
  JLabel casero=new JLabel("Ingrese lo siguientes datos por favor");
        this.add(d,BorderLayout.SOUTH);
         this.add(casero,BorderLayout.CENTER);
        this.add(label,BorderLayout.NORTH);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        this.addWindowListener(new controladorCierre());
        this.setResizable(false);
       
   }
}
