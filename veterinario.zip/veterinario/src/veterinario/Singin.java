/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package veterinario;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author eduardo
 */
public class Singin extends JFrame {
       private datosCliente d;
       private String s;
          private JLabel casero;
         private Container ea;
        public Singin(Container ea) {
            ea.setVisible(false);
          this.setSize(340,600);
          this.ea=ea;
          d=new datosCliente(ea,this);
          initComponents();
        }
           public Singin(int i) {
        this.setSize(340,600);
        d=new datosCliente(this,i);
          initComponents();
        }
         public Singin(String s) {
          this.setSize(340,600);
         this.s=s;
         initComponents(s);
        }
         private void initComponents() {
  
        Container contenedor=this.getContentPane();
        contenedor.setLayout(new BorderLayout());
        
             ImageIcon imagen=new ImageIcon("src/imagenes/beagle.jpg");
              JLabel label=new JLabel();
              label.setSize(340,300);
        Icon icon=new ImageIcon(imagen.getImage().getScaledInstance(label.getWidth(),label.getHeight(),Image.SCALE_DEFAULT));
  label.setIcon(icon);
        casero=new JLabel("De click aqui si quiere ingresar al programa hogar temporal");
        casero.addMouseListener(new mouseListener(){
                @Override
    public void mouseClicked(MouseEvent me) {
         Adoptable adopta=new Adoptable();
         if(d.getNombre().equals("") || d.getDireccion().equals("")){
              JOptionPane.showMessageDialog(null, "Faltan datos");
         }else{
         adopta.setPrestador(d.getNombre(), d.getDireccion());
    }
    }
        });
        this.add(d,BorderLayout.SOUTH);
        this.add(casero,BorderLayout.CENTER);
        this.add(label,BorderLayout.NORTH);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        this.addWindowListener(new controladorCierre());
        this.setResizable(false);
       
   }
         private void initComponents(String s){
    
                     Container contenedor=this.getContentPane();
        contenedor.setLayout(new BorderLayout());
        d=new datosCliente(s);
             ImageIcon imagen=new ImageIcon("src/imagenes/beagle.jpg");
              JLabel label=new JLabel();
              label.setSize(340,300);
        Icon icon=new ImageIcon(imagen.getImage().getScaledInstance(label.getWidth(),label.getHeight(),Image.SCALE_DEFAULT));
  label.setIcon(icon);
        casero=new JLabel("      listo para darle hogar a "+ s);
        this.add(d,BorderLayout.SOUTH);
        this.add(casero,BorderLayout.CENTER);
        this.add(label,BorderLayout.NORTH);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
         }

    public datosCliente getD() {
        return d;
    }
         
}
